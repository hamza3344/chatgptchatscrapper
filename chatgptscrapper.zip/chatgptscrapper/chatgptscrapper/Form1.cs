﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace chatgptscrapper
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitBrowser();
        }
        private async Task initizated()
        {
            await webView21.EnsureCoreWebView2Async(null);
        }
        public async void InitBrowser()
        {
            await initizated();
            webView21.CoreWebView2.Navigate("https://chat.openai.com/share/65852337-ebfe-4b2c-828f-921e8e56f519");
        }

        private void webView21_NavigationCompleted(object sender, CoreWebView2NavigationCompletedEventArgs e)
        {
            getfullpage();
        }
        public async void getfullpage()
        {
            var html = await webView21.CoreWebView2.ExecuteScriptAsync("document.body.outerHTML");
            string x = html.Replace("\\u003C", "<").Replace("\\\"", "\"");
            HtmlAgilityPack.HtmlDocument doc=new HtmlAgilityPack.HtmlDocument();
            doc.LoadHtml(x);
            foreach(var item in doc.DocumentNode.SelectNodes("//div[contains(@class,'text-message')]"))
            {
                MessageBox.Show(item.InnerText);
            }

        }
    }
}
